/* FIR30th.h                                */
/* DF2 filter coefficients                  */
/* exported from MATLAB using fir_dump2c.m  */


#define B_LENGTH 31

extern float B[];

