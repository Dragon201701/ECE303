// Welch, Wright, & Morrow, 
// Real-time Digital Signal Processing, 2017

/* coeff.c                             */
/* FIR filter coefficients             */
/* exported by MATLAB using FIR_DUMP2C */

#include "coeff.h"

float B[N+1] = {1};
