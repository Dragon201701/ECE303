The content for this Appendix can be downloaded from
http://www.rt-dsp.com/

Please note that C8X_Control and C8X_DEBUG require DSP programs to be compiled to COFF files. To do this, select a version 7.X C compiler in the CCS project "Compiler version" setting, and select "Legacy COFF" as the CCS project "Output format" setting.