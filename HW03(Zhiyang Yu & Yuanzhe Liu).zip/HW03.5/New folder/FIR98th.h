/* FIR98th.h                                */
/* DF2 filter coefficients                  */
/* exported from MATLAB using fir_dump2c.m  */


#define B_LENGTH 99

extern float B[];

