// Welch, Wright, & Morrow, 
// Real-time Digital Signal Processing, 2017

/* coeff.h ... sqrt-root raised-cosine      */
/* DF2 filter coefficients                  */
/* exported from MATLAB using fir_dump2c.m  */


#define B_SIZE 121

extern float B[];

