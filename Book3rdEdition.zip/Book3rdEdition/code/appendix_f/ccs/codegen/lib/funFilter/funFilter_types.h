/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: funFilter_types.h
 *
 * MATLAB Coder version            : 2.8
 * C/C++ source code generated on  : 23-Jul-2015 18:17:32
 */

#ifndef __FUNFILTER_TYPES_H__
#define __FUNFILTER_TYPES_H__

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for funFilter_types.h
 *
 * [EOF]
 */
