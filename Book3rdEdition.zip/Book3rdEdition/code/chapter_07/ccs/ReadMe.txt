For the DSK6713, use the files in FltFrm.
For the OMAP-L138 (LCDK and Zoom platforms), use the files in FltFrm_6748.