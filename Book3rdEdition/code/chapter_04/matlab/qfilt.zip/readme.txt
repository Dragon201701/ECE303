QFILT

Installation and operation directions:

	1. Unzip the file (if you are reading this file you have
	   already completed this step).

	2. Create a new directory and copy all of the unzipped files 
	   associated with this program into that new directory.

	3. (Probably not necessary) Edit the file nextpath.m and 
           change the "chdir" command's path to the directory you 
           created in step 2.

	4. Add the new directory to your MATLAB path.  This can be
	   accomplished using the Path Browser on the MATLAB toolbar.

	5. First you design your filter (step 6 and 7), then you run qfilt 
           on it (step 8).

	6. From the MATLAB command line type    "sptool"
	   then push the Enter key.

	7. Create your desired filter and export its filter structure
	   to the MATLAB workspace.  This is accomplished by selecting
	   File on the figure titled SPTool, Export..., and finally, 
	   Export to Workspace.  The current version of GUI_DSK will 
	   only work with the sptool created data structure "filt1".  
	   Verify you are doing your filter design using the name 
	   "filt1"!

	8. From the MATLAB command line type    "qfilt"  
	   then push the Enter key. 

	9. If the GUI is not self-explanatory, left click on the 
	   "Info" button.

Summary from the Info file:

 This is a demonstration of the effects of digital filter
 coefficient quantization on the filter characteristics.
 The filter can also be easily implimented on a C31 DSK.

 Designing a filter using "sptool.m" ...
 export the filter parameters to the workspace as "filt1" ...
 select a "quantization method" ...
 select a "plot method" ...
 select a "number of bits" ...
 note: you can select fixed or floating point implementation ...
 finally, click on "Apply" to replot the figure.
 DSK control (parallel port, sample frequency, anti-aliasing 
 filter control) is also provided.  All of these parameters have
 default settings, so "Apply" the "Load/Run DSK" can be selected 
 for rapid filter evaluation and implementation.

 Fixed point ALU processing IS being added.  Currently, only the filter
 coefficients are quantized.  All subsequent calculations are
 accomplished using the double precision MATLAB default.

 The "Apply" button replots the figure with the new parameters.
 The "Load/Run DSK" button loads the filter coefficients into the DSK.
 The "Magnify" button turns on the left and right mouse button "zoom".
 The "Grid on/off" button toggles the plot grid.
 The "Info" button activates a information/help window.
 The "End program" button terminates the gui and closes the figure.

 [filt1,filt2]=q_filtd(filt1,n_bits,technique,method)

 filt1     - a data structure exported from sptool.m
 n_bits    - the number of bits for the filter coefficients
 technique - the technique used to quantize the filter coefficients
 method    - the plotting method selected
 filt2     - the quantized filter coefficient version of filt1

 Requires Signal Processing Toolbox version 4.0 or higher
 (written w/ MATLAB ver 5.2 and the SP toolbox ver 4.1)

 This m-file calls q_zpln_b.m and stable.m

 *************************** PROGRAM STATUS ****************************
 Adding fixed point implementation - Mike Morrow's 2 new files
 Need to update to MATLAB version 5.3 - new SP toolbox "tf2sos" commands
                                      - remove zoom button
 Auto update of path (nextpath.m idea)
 Add a legend to the pole/zero plot
 Add filt? import capability
 Add rename of output capability ... filt?a (this is just an idea!)
 Demo version to interface with a spectrum analyzer for actual results
 ***********************************************************************

 Last major revision(s): 9 July 98, 11 Nov 98, 18 May 1999

 Copyright (c) 7 December 1997, 1998, and 1999 by
 Thad B. Welch (t.b.welch@ieee.org) and
 Cameron H. G. Wright (c.h.g.wright@ieee.org)
