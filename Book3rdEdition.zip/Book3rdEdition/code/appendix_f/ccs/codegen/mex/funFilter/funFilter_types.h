/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * funFilter_types.h
 *
 * Code generation for function 'funFilter'
 *
 */

#ifndef __FUNFILTER_TYPES_H__
#define __FUNFILTER_TYPES_H__

/* Include files */
#include "rtwtypes.h"
#endif

/* End of code generation (funFilter_types.h) */
