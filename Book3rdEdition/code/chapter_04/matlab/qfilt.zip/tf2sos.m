% sos=tf2sos(filt1);
%
% filt1 - data structure from sptool export to workspace utility.
% Transfer function to second order section conversion.
% Returns a matrix sos (6 columns -> b0 b1 b2 a0 a1 a2 coefficients).
%
% by Thad Welch {USNA, t.b.welch@ieee.org}
% copyright (c) 9 Nov 1998, last rev 9 Nov 1998

function [sos]=tf2sos(filt1);

num_order=length(filt1.tf.num);
den_order=length(filt1.tf.den);
difference=num_order-den_order;

if difference==0
  [Z,P,k]=tf2zp(filt1.tf.num,filt1.tf.den);
elseif difference<0
  [Z,P,k]=tf2zp([filt1.tf.num zeros(1,-difference)],filt1.tf.den);
else
  [Z,P,k]=tf2zp(filt1.tf.num,[filt1.tf.den zeros(1,difference)]);
end    

sos=zp2sos(Z,P,k);
