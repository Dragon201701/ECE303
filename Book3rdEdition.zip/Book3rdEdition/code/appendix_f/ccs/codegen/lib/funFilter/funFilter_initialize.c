/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: funFilter_initialize.c
 *
 * MATLAB Coder version            : 2.8
 * C/C++ source code generated on  : 23-Jul-2015 18:17:32
 */

/* Include Files */
#include "funFilter.h"
#include "funFilter_initialize.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void funFilter_initialize(void)
{
}

/*
 * File trailer for funFilter_initialize.c
 *
 * [EOF]
 */
