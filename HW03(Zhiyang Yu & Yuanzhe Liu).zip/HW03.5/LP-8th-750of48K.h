/* LP-8th-750of48K.h                        */
/* SOS filter coefficients                  */
/* exported from MATLAB using sos_dump2c.m  */
/* order is {b0, b1, b2, a0, a1, a2}        */


#define SOS_1_SECTIONS 4

extern float SOS_1[SOS_1_SECTIONS][6];

