C31_bqd.DLL Help File

This program implements a cascades second order section of a 
maximum 256th order IIR filter, directly downloaded and executed 
on a C31 DSK.  One coefficient matrix argument is required.  
Optional arguments can be used to specify the printer port used 
to connect to the DSK, and to alter the sampling frequency of the 
DSK.

At the Matlab command line, 

C31_bqd(sos, < LPT#, <sample_divider>, <bpfilter> > >)

Arguments: 
sos	The secton order section coefficients
      (i.e. filt1.sos)

LPT#	This optional argument specifies the LPT port to use to 
      connect to the DSK.  If not specified, LPT1 will be used.  
      Allowable values are 1, 2 and 3.

sample_divider	 This optional argument sets the DSK sampling 
                frequency divider to control the DSK sampling
                frequency.  The DSK sampling frequency can be 
                calculated as fs = 284.091kHz / sample_divider
                The allowable range of values for sample_divider 
                is 14 ((20.29kHz) thru 63 (4.51kHz).  If not 
                specified, a default value of 28 (10.15kHz) is 
                used. (Note: to specifiy the sample_divider 
                argument, you MUST include LPT# argument.)

bpfilter	  This argument specifies whether to enable the AIC 
           anti-aliasing filter.  A non-zero value will cause 
           the filter to be enabled.  By default, the filter is 
           disabled. (Note: to specifiy the bpfilter argument, 
           you MUST include LPT# and sample_divider arguments.)

(c) Michael Morrow 1998