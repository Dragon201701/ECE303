// Welch, Wright, & Morrow, 
// Real-time Digital Signal Processing, 2017

/* coeff_HP.h                          */
/* FIR filter coefficients             */
/* exported by MATLAB using FIR_DUMP2C */

//#define N 128

extern float B_HP[];

