/* IIR4th.h                            */
/* IIR filter coefficients             */
/* exported by MATLAB using IIR_dump2C */
/* Michael G. Morrow - 2000            */


#define N 5

extern float D[];

extern float C[];

