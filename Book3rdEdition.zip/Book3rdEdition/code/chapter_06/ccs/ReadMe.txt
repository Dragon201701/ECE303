For the DSK6713, use the files in Frame_EDMA_6713.
For the OMAP-L138 (LCDK and Zoom platforms), use the files in Frame_EDMA_6748.
