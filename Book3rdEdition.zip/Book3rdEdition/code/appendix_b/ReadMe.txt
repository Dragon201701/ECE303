The content for this Appendix B can be downloaded from
http://www.rt-dsp.com/