/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: funFilter_terminate.h
 *
 * MATLAB Coder version            : 2.8
 * C/C++ source code generated on  : 23-Jul-2015 18:17:32
 */

#ifndef __FUNFILTER_TERMINATE_H__
#define __FUNFILTER_TERMINATE_H__

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "funFilter_types.h"

/* Function Declarations */
extern void funFilter_terminate(void);

#endif

/*
 * File trailer for funFilter_terminate.h
 *
 * [EOF]
 */
