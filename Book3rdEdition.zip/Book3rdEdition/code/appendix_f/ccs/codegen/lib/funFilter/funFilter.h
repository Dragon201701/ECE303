/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: funFilter.h
 *
 * MATLAB Coder version            : 2.8
 * C/C++ source code generated on  : 23-Jul-2015 18:17:32
 */

#ifndef __FUNFILTER_H__
#define __FUNFILTER_H__

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "funFilter_types.h"

/* Function Declarations */
extern float funFilter(float xLeft[4], const float B[4], short N);

#endif

/*
 * File trailer for funFilter.h
 *
 * [EOF]
 */
