/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: funFilter_terminate.c
 *
 * MATLAB Coder version            : 2.8
 * C/C++ source code generated on  : 23-Jul-2015 18:17:32
 */

/* Include Files */
#include "funFilter.h"
#include "funFilter_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void funFilter_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for funFilter_terminate.c
 *
 * [EOF]
 */
