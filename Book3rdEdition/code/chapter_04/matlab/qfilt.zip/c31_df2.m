C31_DF2.DLL Help File

This program implements a direct realization (Direct Form 2) of a 
maximum 254th order IIR filter, directly downloaded and executed 
on a C31 DSK.  It also functions as an FIR filter if the A 
coefficient array is one element, or all elements are set to 0.
Two coefficient matrix arguments are required.  The first element 
of the A coefficient array is ignored, as it is always 1.  
Optional arguments can be used to specify the printer port used 
to connect to the DSK, and to alter the sampling frequency of the 
DSK.

At the Matlab command line, 

C31_DF2(numerator_coeff, denominator_coeff, < LPT#, 
<sample_divider>, <bpfilter> > >)

Arguments: 
numerator_coeff	The B coefficients (b[0] - b[n]) 
                  (i.e. filt1.tf.num)

denominator_coeff	The A coefficients (a[0] - a[n]) 
                  (i.e. filt1.tf.den)

LPT#	This optional argument specifies the LPT port to use to 
      connect to the DSK.  If not specified, LPT1 will be used.  
      Allowable values are 1, 2 and 3.

sample_divider	 This optional argument sets the DSK sampling 
                frequency divider to control the DSK sampling
                frequency.  The DSK sampling frequency can be 
                calculated as fs = 284.091kHz / sample_divider
                The allowable range of values for sample_divider 
                is 14 ((20.29kHz) thru 63 (4.51kHz).  If not 
                specified, a default value of 28 (10.15kHz) is 
                used. (Note: to specifiy the sample_divider 
                argument, you MUST include LPT# argument.)

bpfilter	  This argument specifies whether to enable the AIC 
           anti-aliasing filter.  A non-zero value will cause 
           the filter to be enabled.  By default, the filter is 
           disabled. (Note: to specifiy the bpfilter argument, 
           you MUST include LPT# and sample_divider arguments.)

(c) Michael Morrow 1998