% changes the directory to the location of 
% the nextstep.m program
%
% last rev 15 May 1999

chdir c:\matlab\mymfiles\nextstep0599