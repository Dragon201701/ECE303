Additional content for Appendix E can be downloaded from
http://www.rt-dsp.com/