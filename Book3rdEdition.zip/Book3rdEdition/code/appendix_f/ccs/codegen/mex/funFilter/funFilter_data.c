/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * funFilter_data.c
 *
 * Code generation for function 'funFilter_data'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "funFilter.h"
#include "funFilter_data.h"

/* Variable Definitions */
emlrtCTX emlrtRootTLSGlobal = NULL;
const volatile char_T *emlrtBreakCheckR2012bFlagVar;
emlrtContext emlrtContextGlobal = { true, false, 131418U, NULL, "funFilter",
  NULL, false, { 2045744189U, 2170104910U, 2743257031U, 4284093946U }, NULL };

/* End of code generation (funFilter_data.c) */
