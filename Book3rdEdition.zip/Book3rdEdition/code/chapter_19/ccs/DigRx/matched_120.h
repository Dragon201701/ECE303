// Welch, Wright, & Morrow, 
// Real-time Digital Signal Processing, 2017

/* Matched.h                           */
/* FIR filter coefficients              */
/* exported by MATLAB using FIR_dump2c  */

#define M 120

extern float B_MF[];

