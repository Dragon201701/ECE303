function [filt1,filt2]=q_filtd(filt1,n_bits,technique,method)
% This is a demonstration of the effects of digital filter
% coefficient quantization on the filter characteristics.
% The filter can also be easily implimented on a C31 DSK.
%
% Designing a filter using "sptool.m" ...
% export the filter parameters to the workspace as "filt1" ...
% select a "quantization method" ...
% select a "plot method" ...
% select a "number of bits" ...
% note: you can select fixed or floating point implementation ...
% finally, click on "Apply" to replot the figure.
% DSK control (parallel port, sample frequency, anti-aliasing 
% filter control) is also provided.  All of these parameters have
% default settings, so "Apply" the "Load/Run DSK" can be selected 
% for rapid filter evaluation and implementation.
%
% Fixed point ALU processing IS being added.  Currently, only the filter
% coefficients are quantized.  All subsequent calculations are
% accomplished using the double precision MATLAB default.
%
% The "Apply" button replots the figure with the new parameters.
% The "Load/Run DSK" button loads the filter coefficients into the DSK.
% The "Magnify" button turns on the left and right mouse button "zoom".
% The "Grid on/off" button toggles the plot grid.
% The "Info" button activates a information/help window.
% The "End program" button terminates the gui and closes the figure.
%
% [filt1,filt2]=q_filtd(filt1,n_bits,technique,method)
%
% filt1     - a data structure exported from sptool.m
% n_bits    - the number of bits for the filter coefficients
% technique - the technique used to quantize the filter coefficients
% method    - the plotting method selected
% filt2     - the quantized filter coefficient version of filt1
%
% Requires Signal Processing Toolbox version 4.0 or higher
% (written w/ MATLAB ver 5.2 and the SP toolbox ver 4.1)
%
% This m-file calls q_zpln_b.m and stable.m
%
% *************************** PROGRAM STATUS ****************************
% Adding fixed point implementation - Mike Morrow's 2 new files
% Need to update to MATLAB version 5.3 - new SP toolbox "tf2sos" commands
%                                      - remove zoom button
% Auto update of path (nextpath.m idea)
% Add a legend to the pole/zero plot
% Add filt? import capability
% Add rename of output capability ... filt?a (this is just an idea!)
% Demo version to interface with a spectrum analyzer for actual results
% ***********************************************************************
%
% Last major revision(s): 9 July 98, 11 Nov 98, 18 May 1999
%
% Copyright (c) 7 December 1997, 1998, and 1999 by
% Thad B. Welch (t.b.welch@ieee.org) and
% Cameron H. G. Wright (c.h.g.wright@ieee.org)

% set up variables
filt2=filt1;
n_bits_string=num2str(n_bits);
num_order=length(filt1.tf.num);
den_order=length(filt1.tf.den);
difference=num_order-den_order;
old_numerator=filt1.tf.num;
old_denominator=filt1.tf.den;
Fs=filt1.Fs;
N=512; % number of points to evaluate
full_scale=2^(n_bits-1);

% quantization technique declaration
if  technique==1
  filt1.sos=[];
  filt2.sos=[];
  technique_string='Rounding';
  new_numerator=round(filt1.tf.num*full_scale)/full_scale;
  new_denominator=round(filt1.tf.den*full_scale)/full_scale;
  [H_old,F_old]=freqz(old_numerator,old_denominator,N,Fs);
  [H_new,F_new]=freqz(new_numerator,new_denominator,N,Fs);
elseif technique==2
  filt1.sos=[];
  filt2.sos=[];
  technique_string='Truncation';
  new_numerator=fix(filt1.tf.num*full_scale)/full_scale;
  new_denominator=fix(filt1.tf.den*full_scale)/full_scale;
  [H_old,F_old]=freqz(old_numerator,old_denominator,N,Fs);
  [H_new,F_new]=freqz(new_numerator,new_denominator,N,Fs);
elseif technique==3
  technique_string='Truncated Second Order Sections';
  if difference==0
    [Z,P,k]=tf2zp(filt1.tf.num,filt1.tf.den);
  elseif difference<0
    [Z,P,k]=tf2zp([filt1.tf.num zeros(1,-difference)],filt1.tf.den);
  else
    [Z,P,k]=tf2zp(filt1.tf.num,[filt1.tf.den zeros(1,difference)]);
  end    
  filt1.sos=zp2sos(Z,P,k);
  filt2.sos=fix(filt1.sos*full_scale)/full_scale;
  [new_numerator,new_denominator]=sos2tf(filt2.sos);
  [H_old,F_old]=freqz(old_numerator,old_denominator,N,Fs);
  [H_new,F_new]=freqz(new_numerator,new_denominator,N,Fs);
else
  technique_string='Rounded Second Order Sections';
  if difference==0
    [Z,P,k]=tf2zp(filt1.tf.num,filt1.tf.den);
  elseif difference<0
    [Z,P,k]=tf2zp([filt1.tf.num zeros(1,-difference)],filt1.tf.den);
  else
    [Z,P,k]=tf2zp(filt1.tf.num,[filt1.tf.den zeros(1,difference)]);
  end    
  filt1.sos=zp2sos(Z,P,k);
  filt2.sos=round(filt1.sos*full_scale)/full_scale;
  [new_numerator,new_denominator]=sos2tf(filt2.sos);
  [H_old,F_old]=freqz(old_numerator,old_denominator,N,Fs);
  [H_new,F_new]=freqz(new_numerator,new_denominator,N,Fs);
end

% stability check
[s1,s2,p1,p2]=stable(old_numerator,old_denominator,new_numerator,new_denominator);

if method==1 % show the difference in frequency response
  figure(1);
  warning off; % suppress warning for log of zero
  plot(F_new,20*log10(abs(H_new)),'r-') % solid red line
  hold on
  plot(F_old,20*log10(abs(H_old)),'b-') % solid blue line
  title(['Effects of ',n_bits_string, ' Bit Filter Coefficient Quantization Using ',technique_string])
  xlabel('frequency (Hz)')
  ylabel('magnitude response (dB)')
  legend('quantized','double precision ',3)
  grid on
  if ((s1==0)|(s2==0))
    set(gca,'Color',[1 0.690196078431373 0.690196078431373])
    title(['UNSTABLE - poles outside the unit circle (',n_bits_string, ' Bit Filter Coefficient Quantization Using ',technique_string,')'])
  end
  hold off
  warning on; % turn warnings back on
elseif method==2 % show the difference in phase response
  figure(1);
  plot(F_old,unwrap(angle(H_old))*180/pi,'b-'); % solid blue line
  hold on
  plot(F_new,unwrap(angle(H_new))*180/pi,'r-') % solid red line
  title(['Effects of ',n_bits_string, ' Bit Filter Coefficient Quantization Using ',technique_string])
  xlabel('frequency (Hz)')
  ylabel('phase response (deg)')
  legend('double precision ', 'quantized',3)
  grid on
  if ((s1==0)|(s2==0))
    set(gca,'Color',[1 0.690196078431373 0.690196078431373])
    title(['UNSTABLE - poles outside the unit circle (',n_bits_string, ' Bit Filter Coefficient Quantization Using ',technique_string,')'])
  end
  hold off
else % show the difference in the pole-zero plot
  figure(1);
  q_zpln_b(old_numerator,old_denominator,new_numerator,new_denominator,p1,p2);
  title(['Effects of ',n_bits_string, ' Bit Filter Coefficient Quantization Using ',technique_string])
  if ((s1==0)|(s2==0))
    set(gca,'Color',[1 0.690196078431373 0.690196078431373])
    title(['UNSTABLE - poles outside the unit circle (',n_bits_string, ' Bit Filter Coefficient Quantization Using ',technique_string,')'])
  end  
end

% updating filt2
filt2.tf.num=new_numerator;
filt2.tf.den=new_denominator;
filt2.label='filt2';
