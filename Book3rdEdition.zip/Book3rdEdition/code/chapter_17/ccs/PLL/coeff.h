// Welch, Wright, & Morrow, 
// Real-time Digital Signal Processing, 2017

/* coeff.h                              */
/* FIR filter coefficients              */
/* exported by MATLAB using FIR_dump2c  */

#define N 30

extern float B[];

